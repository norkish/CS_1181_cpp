//
// Created by Paul Bodily on 11/16/23.
//

#ifndef HANOI_CONSTANTS_H
#define HANOI_CONSTANTS_H

const int NUM_DISKS = 3;
const int NUM_TOWERS = 3;

#endif //HANOI_CONSTANTS_H
