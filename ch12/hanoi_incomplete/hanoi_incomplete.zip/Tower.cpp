//
// Created by Paul Bodily on 11/16/23.
//
#include <iostream>

#include "Disk.h"
#include "Tower.h"

using namespace std;

/**
 *
 * @return true if the disk stack at this location is empty
 */
bool Tower::isEmpty() const{
    // TODO
}

/**
 * Returns (but does not remove) the topmost disk of this tower
 * program exits with error code and message if tower is empty
 * @return
 */
Disk Tower::top() const{
    // TODO
}

/**
 * Returns and removes the topmost disk of this tower
 * program exits with error code and message if tower is empty
 * @return
 */
Disk Tower::pop() {
    // TODO
}

/**
 *
 * @return the number of disks on this Tower as an integer
 */
int Tower::numDisks() const {
    // TODO
}

/**
 * Adds Disk d to top of this Tower's disk stack
 * @param d
 */
void Tower::push(const Disk& d) {
    // TODO
}