#include <iostream>

#include "Game.h"

using namespace std;

int main() {
    Game g;
    // TODO: implement a text-based interface that enables the user to play a game of Towers of Hanoi


    return 0;
}
