//
// Created by Paul Bodily on 11/16/23.
//

#ifndef HANOI_DISK_H
#define HANOI_DISK_H

struct Disk {
    int width;

    Disk(int w);
};

#endif //HANOI_DISK_H
