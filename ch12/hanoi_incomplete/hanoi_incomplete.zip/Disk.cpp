//
// Created by Paul Bodily on 11/16/23.
//

#include "Disk.h"

/**
 * Constructor that initializes width of new Disk to be equal to w
 * @param w
 */
Disk::Disk(int w) {
    // TODO
}